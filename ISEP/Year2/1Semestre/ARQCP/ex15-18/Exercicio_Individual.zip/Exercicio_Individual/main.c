#include <stdio.h>
#include <string.h>
#include "equipa.h"

void inserir_dados(Equipa * ptr){
	ptr-> nome = "Joao Flores";
	ptr-> num_inscricao= 1171409;
	ptr->resultados= 1020;
	}




int main(){
	
	Equipa e;
	Equipa *ptr=&e;
	inserir_dados(ptr);
	printf("nome:%s\n",ptr-> nome);
	printf("num:%d\n",ptr-> num_inscricao);
	
	printf("res %0b \n",ptr->resultados);
	
	
	
	int p=pontuacao(ptr->resultados);
	printf("pontuacao: %d\n",p);
	return 0;
	}
