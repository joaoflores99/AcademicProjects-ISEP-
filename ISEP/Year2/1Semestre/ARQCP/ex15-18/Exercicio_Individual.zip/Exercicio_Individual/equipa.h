
typedef struct{ 
	char *nome;  // size4
	int num_inscricao; // size 4 
	unsigned short resultados; // size 2 
}Equipa;

int pontuacao (unsigned short resultados);
